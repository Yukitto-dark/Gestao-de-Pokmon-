﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GestaoDePokemon.View.Telas
{
    /// <summary>
    /// Interação lógica para Mapas.xam
    /// </summary>
    public partial class Mapas : Page
    {
        public Mapas()
        {
            InitializeComponent();
        }

        private void Navegar_Click(object sender, RoutedEventArgs e)
        {
            Navegacao.Navegar(this, sender);
        }

        private void Regiao_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button botao && botao.Tag is string regiao)
            {
                Regioes.RegiaoInicial = regiao;
                NavigationService?.Navigate(new Uri("/View/Telas/Regioes.xaml", UriKind.Relative));
            }
        }
    }
}
