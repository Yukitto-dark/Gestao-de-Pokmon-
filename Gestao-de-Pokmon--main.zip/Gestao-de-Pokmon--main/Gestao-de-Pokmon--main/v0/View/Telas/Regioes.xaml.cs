﻿using System.Windows;
using System.Windows.Controls;

namespace GestaoDePokemon.View.Telas
{
    public partial class Regioes : Page
    {
        public static string RegiaoInicial { get; set; } = "Kanto";

        private bool _inicializado;

        public Regioes()
        {
            InitializeComponent();
            Loaded += Regioes_Loaded;
        }

        private void Regioes_Loaded(object sender, RoutedEventArgs e)
        {
            if (_inicializado)
                return;

            _inicializado = true;

            string regiao = RegiaoInicial;

            RadioButton aba = regiao.ToLowerInvariant() switch
            {
                "hoenn" => Tab_Hoenn,
                "johto" => Tab_Johto,
                _ => Tab_Kanto
            };

            if (aba.IsChecked == true)
                PopularRotas(aba.Tag as string ?? "");
            else
                aba.IsChecked = true;
        }

        private void Regiao_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton aba && Lista_Rotas != null)
                PopularRotas(aba.Tag as string ?? "");
        }

        private void PopularRotas(string regiao)
        {
            Lista_Rotas.Children.Clear();

            (int inicio, int fim) = regiao.ToLowerInvariant() switch
            {
                "hoenn" => (101, 134),
                "johto" => (29, 46),
                _ => (1, 28)
            };

            Style estilo = (Style)FindResource("BotaoRota");

            for (int numero = inicio; numero <= fim; numero++)
            {
                var botao = new Button
                {
                    Content = $"Rota {numero}",
                    Style = estilo,
                    Tag = numero
                };
                botao.Click += Rota_Click;
                Lista_Rotas.Children.Add(botao);
            }

            Titulo_Rota.Text = "Informações da rota";
            Rotas_Scroll.ScrollToTop();
            Info_Scroll.ScrollToTop();
        }

        private void Rota_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button botao && botao.Tag is int numero)
            {
                Titulo_Rota.Text = $"Rota {numero}";
                Info_Scroll.ScrollToTop();
            }
        }

        private void Navegar_Click(object sender, RoutedEventArgs e)
        {
            Navegacao.Navegar(this, sender);
        }
    }
}
