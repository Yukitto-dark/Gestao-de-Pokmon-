using System;
using System.Collections.Generic;

namespace GestaoDePokemon.View.Telas
{
    internal static class FavoritosService
    {
        public const int Limite = 6;

        private static readonly List<int> ids = new();

        public static event Action? Alterado;

        public static IReadOnlyList<int> Ids => ids;

        public static bool EhFavorito(int id) => ids.Contains(id);

        public static bool Alternar(int id, out bool limiteAtingido)
        {
            limiteAtingido = false;

            if (ids.Remove(id))
            {
                Alterado?.Invoke();
                return false;
            }

            if (ids.Count >= Limite)
            {
                limiteAtingido = true;
                return false;
            }

            ids.Add(id);
            Alterado?.Invoke();
            return true;
        }
    }
}
